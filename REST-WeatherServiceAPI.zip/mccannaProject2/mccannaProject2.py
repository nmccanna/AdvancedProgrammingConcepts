import requests

# Method to get user's location
def get_user_location():
    latitude = input("Enter latitude: ")
    longitude = input("Enter longitude: ")
    return latitude, longitude

# Method to get location info from weather API
def get_location_info(latitude, longitude):
    try:
        # API request to get location info
        response = requests.get(f"https://api.weather.gov/points/{latitude},{longitude}")
        data = response.json()  # Convert API response to JSON
        # Returns the office, gridX, and gridY values from the API response
        return data['properties']['cwa'], data['properties']['gridX'], data['properties']['gridY']
    except Exception:
        print("Could not retrieve grid values for provided coordinates.")
        return None, None, None 

# Method to get forecast from weather API
def get_forecast(office, gridX, gridY):
    try:
        # API request to get forecast
        response = requests.get(f"https://api.weather.gov/gridpoints/{office}/{gridX},{gridY}/forecast")
        data = response.json()  # Convert API response to JSON
        return data['properties']['periods']  # Returns the forecast periods
    except Exception:
        print("Failed to fetch forecast.")
        return None

# Main method
def main():
    while True:
        latitude, longitude = get_user_location()
        office, gridX, gridY = get_location_info(latitude, longitude)
        if office and gridX and gridY:
            forecast = get_forecast(office, gridX, gridY)
            if forecast is not None:
                for period in forecast:
                    print(f"{period['name']}: {period['shortForecast']}, {period['temperature']} {period['temperatureUnit']}")
                break

main()