https://www.weather.gov/documentation/services-web-api

https://realpython.com/python-api/

https://requests.readthedocs.io/en/latest/

https://automatetheboringstuff.com

https://docs.python.org/3/

https://www.codecademy.com/learn/learn-python-3

