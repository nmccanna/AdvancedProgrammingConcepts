﻿--------------------------------------------------------------
Nikhil McCanna - Project 6 - CSC6304
--------------------------------------------------------------


This application was made with Apple Xcode using Swift.


It is intended to work with Apple MacOS - Sonoma 14.1.2 (Latest version)


The purpose of this app is to open “https://www.merrimack.edu” in the Safari browser after clicking the blue Open Website button in the center of the screen.


Potential Issue:


When opening the app, you might get a warning that says “Apple can’t check app for malicious software.”

Apple provides a work around for this:


https://support.apple.com/guide/mac-help/apple-cant-check-app-for-malicious-software-mchleab3a043/mac


--------------------------------------------------------------
--------------------------------------------------------------