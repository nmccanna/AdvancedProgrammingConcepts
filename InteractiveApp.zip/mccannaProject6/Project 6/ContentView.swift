//
//  ContentView.swift
//  Project 6
//
//  Created by Nikhil McCanna on 12/09/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Link(destination: URL(string: "https://www.merrimack.edu")!) {
            Text("Open Website")
                .font(.title)
                .padding()
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
