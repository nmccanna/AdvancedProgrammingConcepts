//
//  Project_6App.swift
//  Project 6
//
//  Created by Nikhil McCanna on 12/11/23.
//

import SwiftUI

@main
struct Project_6App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
