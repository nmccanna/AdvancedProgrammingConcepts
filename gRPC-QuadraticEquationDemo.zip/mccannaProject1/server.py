from concurrent import futures
import grpc
import quadratic_pb2
import quadratic_pb2_grpc

# Server class inherited from gRPC generated base class
class QuadraticSolverServicer(quadratic_pb2_grpc.QuadraticSolverServicer):
    
    # Solve method that gRPC server will call upon client request
    def Solve(self, request, context):
        # Extract coefficients from request
        a, b, c = request.a, request.b, request.c
        # Calculate discriminant of quadratic equation
        discriminant = b**2 - 4*a*c
        
        # Handle case when a is zero
        if a == 0:
            return quadratic_pb2.Solution(answer="Error: a cannot be zero.")
        # Handle case when discriminant is positive
        elif discriminant > 0:
            x1 = (-b + discriminant**0.5) / (2*a)
            x2 = (-b - discriminant**0.5) / (2*a)
            return quadratic_pb2.Solution(answer=f"Solutions are x1 = {x1} and x2 = {x2}.")
        # Handle case when discriminant is zero
        elif discriminant == 0:
            x = -b / (2*a)
            return quadratic_pb2.Solution(answer=f"Solution is x = {x}.")
        # Handle case when discriminant is negative
        else:
            real_part = -b / (2*a)
            imag_part = abs(discriminant**0.5) / (2*a)
            return quadratic_pb2.Solution(answer=f"Solutions are x1 = {real_part} + {imag_part}i and x2 = {real_part} - {imag_part}i.")

# Serve function sets up and starts gRPC server
def serve():
    port = '50051'  # Defines port number where server will listen
    # Create gRPC server with thread pool executor to handle requests
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    # Add servicer to server
    quadratic_pb2_grpc.add_QuadraticSolverServicer_to_server(QuadraticSolverServicer(), server)
    # Specify address and port for server to listen on
    server.add_insecure_port('[::]:' + port)
    # Print start message with port number
    print("Server started, listening on " + port)
    # Start server
    server.start()
    # Block main thread to keep server running
    server.wait_for_termination()

if __name__ == '__main__':
    serve()
