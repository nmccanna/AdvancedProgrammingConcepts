import grpc
import quadratic_pb2
import quadratic_pb2_grpc

# Main function which runs when script is executed directly
def run():
    # Print start message to console
    print("Starting client...")
    
    # Establish insecure gRPC channel to server at localhost on port 50051
    with grpc.insecure_channel('localhost:50051') as channel:
        # Print message once channel is created
        print("Channel created...")
        
        # Create stub for RPC calls with quadratic solver service
        stub = quadratic_pb2_grpc.QuadraticSolverStub(channel)
        # Print message once stub is created
        print("Stub created...")
        
        # Prompt user to enter coefficients of quadratic equation and convert to floats
        a, b, c = map(float, input("Enter the coefficients a, b, and c separated by space: ").split())
        # Print coefficients which will be sent to server
        print(f"Sending coefficients a = {a}, b = {b}, and c = {c} to server...")
        
        # Call Solve method with coefficients and store response
        response = stub.Solve(quadratic_pb2.Coefficients(a=a, b=b, c=c))
        # Print response
        print(f"Server response: {response.answer}")

if __name__ == '__main__':
    run()
